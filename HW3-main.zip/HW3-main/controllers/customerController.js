const customer = require("../models/customerModel");

exports.getCustomers = (req, res, next) => {
    console.log("HECK")
    customer.fetchAll()
            .then(( rows, fieldData ) => {
            console.log( "rows="); console.log( rows );
            // res.send( "Is seems ok ");
            res.render( 'home', {
                title: "Show Customers (DB)",
                from: 'Home',
                customers: rows[0]
            })
        })
}

// exports.getAddProduct = ( req, res, next) => {
//     res.render( 'admin/addProduct',
//         {
//             from: 'addProduct'
//         })
// }
// exports.getProducts = ( req, res, next ) => {
//     Product.fetchAll()
//         .then(( rows, fieldData ) => {
//             console.log( "ROws="); console.log( rows );
//             // res.send( "Is seems ok ");
//             res.render( 'admin/showProductsAdmin', {
//                 title: "Show Products Available (DB)",
//                 from: 'showProducts',
//                 products: rows[0]
//             })
//         })
// }
// exports.deleteProduct = ( req, res, next ) => {
//     // Left off here ... need to code delete.
//     // It is coded in modles.
//     let id = req.params.id;
//     console.log( `id:${id}`);
//
//     Product.delete( id )
//         .then( (result)  => {
//             res.redirect("/showAdmin");
//         })
//         .catch( err => {
//             console.log( "Error on delete");
//             console.log( err );
//         })
// }
// exports.editProduct = ( req, res, next ) => {
//     let id = req.params.id;
//     console.log("Inside Edit .... id=" + id );
//     // fetch all the records and find the idth one
//     Product.findById(id)
//         .then((rows, fieldData) =>{
//             console.log("ROWS=>");
//             // console.log( rows[0][0] );
//             // console.log( rows );
//
//             // res.send("It must works");
//             res.render( 'admin/ShowUpdateForm', {
//                 title : `Update record:${id} `,
//                 id : rows[0].id,
//                 from: 'updateProducts',
//                 product: rows[0][0]
//             })
//         }).catch( err => {
//         console.log( "DB Error=>");
//         console.log( err );
//     })
// }