const db = require("../util/database");

module.exports = class customer {
    constructor(id, name, email ) {
        this.id = id;
        this.name = name;
        this.email = email;
        // this.description = "It was good it was bad it was ugly";
    }
    save() {
        return db.execute( 'insert into products (id, name, email) ' +
            'values (?, ?, ?)',
            [this.id, this.name, this.email ]
        )
    }
    static fetchAll(){
        return db.execute( "select * from customer");
    }
    static findById( id ){
        return db.execute( "select * from customer where id = ?",
            [id] );
    }
}
