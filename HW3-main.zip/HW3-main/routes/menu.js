const express = require('express');
const router = express.Router();
const dataController = require("../controllers/customerController");

router.get( '/home', dataController.getCustomers);  // for controller
// router.post( '/data', dataController.postData );
// router.get('/about', dataController.getAbout);
// router.get( '/surveyResults', dataController.getResults);

module.exports = router;