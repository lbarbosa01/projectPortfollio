const mysql = require("mysql2");

const pool = mysql.createPool( {
    host: '45.55.136.144',
    user : 'F2023_lbarbosa01',
    password : 'BilledHeron02',
    database : 'F2023_lbarbosa01'
});

module.exports = pool.promise();